"""
CrossBridge AI - RAG 引擎核心
================================
职责:
  1. 加载结构化知识库 (knowledge_base.json)
  2. 把每条资料向量化 (Embedding)
  3. 根据用户问题 + 地区/主题过滤,检索最相关的资料
  4. 把检索结果组装成 Prompt,调用大模型生成带引用的答案
  5. 没有 API key 时,降级为模板答案,保证 Demo 永远能跑

设计要点:
  - 检索用 numpy 余弦相似度做(零额外依赖,MVP 够用;
    生产环境可换成 Chroma / Milvus,接口已留好注释)
  - LLM 支持 Anthropic / OpenAI,二选一,通过环境变量切换
"""

import os
import json
import numpy as np
from functools import lru_cache

# ----------------------------------------------------------------------
# 1. 加载知识库
# ----------------------------------------------------------------------
def load_knowledge_base(path="knowledge_base.json"):
    with open(path, "r", encoding="utf-8") as f:
        docs = json.load(f)
    print(f"[KB] 已加载 {len(docs)} 条资料")
    return docs


# ----------------------------------------------------------------------
# 2. Embedding 模型 (向量化)
#    两种检索后端,自动选择:
#      (A) 语义检索: sentence-transformers 向量模型 (效果好,需联网下载模型)
#      (B) 关键词检索: TF-IDF (零下载、永远能跑,作为降级保底)
#    要最强效果,把 CB_EMBED_MODEL 设为 'BAAI/bge-m3' (跨境多语种最佳)
# ----------------------------------------------------------------------
EMBED_MODEL_NAME = os.environ.get(
    "CB_EMBED_MODEL", "paraphrase-multilingual-MiniLM-L12-v2"
)

@lru_cache(maxsize=1)
def get_embedder():
    """懒加载向量模型;失败则返回 None,触发 TF-IDF 降级。"""
    try:
        from sentence_transformers import SentenceTransformer
        print(f"[Embed] 正在加载向量模型: {EMBED_MODEL_NAME}")
        return SentenceTransformer(EMBED_MODEL_NAME)
    except Exception as e:
        print(f"[Embed] 向量模型不可用,降级为 TF-IDF 关键词检索: {e}")
        return None


def _zh_tokenize(text):
    """简单中文分词:有 jieba 用 jieba,没有就按字切。"""
    try:
        import jieba
        return " ".join(jieba.cut(text))
    except Exception:
        return " ".join(list(text))


# ----------------------------------------------------------------------
# 3. 向量索引
#    优先语义检索;模型加载失败时自动用 TF-IDF。两种后端对上层透明。
# ----------------------------------------------------------------------
class VectorIndex:
    def __init__(self, docs):
        self.docs = docs
        corpus = [f"{d['title']}。{d['content']}" for d in docs]
        self.model = get_embedder()

        if self.model is not None:
            # --- 后端 A: 语义向量 ---
            self.backend = "semantic"
            vecs = self.model.encode(corpus, normalize_embeddings=True,
                                     show_progress_bar=False)
            self.matrix = np.array(vecs, dtype=np.float32)
            print(f"[Index] 语义索引已建立: {self.matrix.shape}")
        else:
            # --- 后端 B: TF-IDF 关键词 ---
            self.backend = "tfidf"
            from sklearn.feature_extraction.text import TfidfVectorizer
            self.vectorizer = TfidfVectorizer(tokenizer=lambda t: t.split(),
                                              token_pattern=None)
            tokenized = [_zh_tokenize(c) for c in corpus]
            self.matrix = self.vectorizer.fit_transform(tokenized)
            print(f"[Index] TF-IDF 索引已建立: {self.matrix.shape}")

    def _query_scores(self, query):
        if self.backend == "semantic":
            q = self.model.encode([query], normalize_embeddings=True,
                                   show_progress_bar=False)[0]
            return self.matrix @ q
        else:
            from sklearn.metrics.pairwise import cosine_similarity
            q = self.vectorizer.transform([_zh_tokenize(query)])
            return cosine_similarity(q, self.matrix)[0]

    def search(self, query, region=None, topic=None, top_k=3):
        """
        检索最相关资料。region / topic 为可选过滤 (None 或 '全部' = 不过滤)。
        返回 [(doc, score), ...]
        """
        scores = self._query_scores(query)
        results = []
        for i, doc in enumerate(self.docs):
            if region and region != "全部" and doc["region"] != region:
                continue
            if topic and topic != "全部" and doc["topic"] != topic:
                continue
            results.append((doc, float(scores[i])))
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:top_k]

    # 生产环境提示:
    # 语义检索后端可直接替换为 Chroma / Milvus:
    #   collection.query(query_embeddings=[q_vec], n_results=top_k,
    #                    where={"region": region})
    # 接口语义一致,无需改动上层逻辑。


# ----------------------------------------------------------------------
# 4. LLM 调用 (带降级)
# ----------------------------------------------------------------------
SYSTEM_PROMPT = """你是 CrossBridge AI,一个跨境普惠金融决策助手,服务大湾区与东南亚的中小企业。

严格遵守以下规则:
1. 只能基于【参考资料】回答,不得编造任何法规、数字或产品条款。
2. 若参考资料不足以回答,要诚实说明"现有资料无法确认",不要猜。
3. 回答要分点、清晰、可操作,面向不懂金融术语的中小企业老板。
4. 你不是律师或会计师,回答末尾必须提示用户最终操作前向银行客户经理或专业人士确认。
5. 绝不提供逃税、洗钱、规避监管等违规建议。
"""

def build_prompt(query, retrieved):
    """把检索结果拼进 Prompt。"""
    context_blocks = []
    for i, (doc, score) in enumerate(retrieved, 1):
        context_blocks.append(
            f"[资料{i}] 来源:{doc['source_name']} | 地区:{doc['region']} | "
            f"生效日:{doc.get('effective_date','-')}\n"
            f"标题:{doc['title']}\n正文:{doc['content']}"
        )
    context = "\n\n".join(context_blocks)
    user_msg = (
        f"【参考资料】\n{context}\n\n"
        f"【用户问题】\n{query}\n\n"
        f"请基于以上资料回答,并在结尾用'信息来源'列出你引用了哪几条资料。"
    )
    return user_msg


def call_llm(query, retrieved):
    """
    调用大模型生成答案。
    优先 Anthropic, 其次 OpenAI; 都没有 key 则降级为模板答案。
    """
    user_msg = build_prompt(query, retrieved)

    # ---- 选项 A: Anthropic Claude ----
    if os.environ.get("ANTHROPIC_API_KEY"):
        try:
            import anthropic
            client = anthropic.Anthropic()
            resp = client.messages.create(
                model="claude-3-5-haiku-20241022",
                max_tokens=1024,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
            )
            return resp.content[0].text
        except Exception as e:
            print(f"[LLM] Anthropic 调用失败,降级处理: {e}")

    # ---- 选项 B: OpenAI ----
    if os.environ.get("OPENAI_API_KEY"):
        try:
            from openai import OpenAI
            client = OpenAI()
            resp = client.chat.completions.create(
                model="gpt-4o-mini",
                max_tokens=1024,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
            )
            return resp.choices[0].message.content
        except Exception as e:
            print(f"[LLM] OpenAI 调用失败,降级处理: {e}")

    # ---- 降级: 无 API key 时的模板答案 (保证 Demo 能跑) ----
    return _fallback_answer(query, retrieved)


def _fallback_answer(query, retrieved):
    """没有大模型时,直接结构化展示检索结果。"""
    if not retrieved:
        return "现有资料库暂时找不到与您问题直接相关的权威资料,建议补充更多数据源或咨询银行客户经理。"
    lines = ["(演示模式:未配置大模型 API,以下为检索到的权威资料摘要)\n"]
    for i, (doc, score) in enumerate(retrieved, 1):
        lines.append(f"{i}. 【{doc['title']}】({doc['source_name']})")
        # 摘要取正文前 80 字
        summary = doc["content"][:80].strip()
        lines.append(f"   要点:{summary}……")
        lines.append("")
    lines.append("⚠️ 以上为参考信息,最终操作前请向中银香港客户经理或专业人士确认。")
    return "\n".join(lines)


# ----------------------------------------------------------------------
# 5. 对外统一入口
# ----------------------------------------------------------------------
class CrossBridgeRAG:
    def __init__(self, kb_path="knowledge_base.json"):
        self.docs = load_knowledge_base(kb_path)
        self.index = VectorIndex(self.docs)

    def ask(self, query, region="全部", topic="全部", top_k=3):
        retrieved = self.index.search(query, region=region, topic=topic, top_k=top_k)
        answer = call_llm(query, retrieved)
        citations = [
            {
                "title": doc["title"],
                "source": doc["source_name"],
                "url": doc["source_url"],
                "date": doc.get("effective_date", "-"),
                "region": doc["region"],
                "score": round(score, 3),
            }
            for doc, score in retrieved
        ]
        return {"answer": answer, "citations": citations}


# ----------------------------------------------------------------------
# 命令行自测
# ----------------------------------------------------------------------
if __name__ == "__main__":
    rag = CrossBridgeRAG()
    q = "我深圳公司想汇款给越南供应商,有什么合规要求?"
    print("\n问题:", q)
    result = rag.ask(q, region="全部", topic="remittance")
    print("\n--- 答案 ---")
    print(result["answer"])
    print("\n--- 引用来源 ---")
    for c in result["citations"]:
        print(f"  [{c['source']}] {c['title']} (相关度 {c['score']})")
