"""
CrossBridge AI - Streamlit 前端
================================
运行方式:
    streamlit run app.py

界面包含:
  - 左侧: 地区 / 主题筛选 + 系统状态
  - 主区: 对话框 + 带引用来源的答案
  - 示例问题快捷按钮(路演时直接点,稳)
"""

import streamlit as st
from rag_engine import CrossBridgeRAG

# ----------------------------------------------------------------------
# 页面配置
# ----------------------------------------------------------------------
st.set_page_config(page_title="CrossBridge AI", page_icon="🌉", layout="wide")

# 地区 / 主题选项 (中文显示 -> 内部代码)
REGIONS = {
    "全部": "全部", "香港": "HK", "大湾区(内地)": "GBA",
    "越南": "VN", "泰国": "TH", "新加坡": "SG", "印尼": "ID",
}
TOPICS = {
    "全部": "全部", "政策合规": "compliance", "跨境汇款": "remittance",
    "信贷融资": "credit", "税务": "tax", "市场进入": "market_entry",
}

# 路演用示例问题(自己测过、答得好的)
SAMPLE_QUESTIONS = [
    "我深圳公司想汇款给越南供应商,有什么合规要求?",
    "中银香港有适合中小企业的跨境贸易融资产品吗?",
    "在新加坡和泰国设公司,税务上有什么区别?",
    "跨境大额电汇,银行会查什么?",
]


# ----------------------------------------------------------------------
# 加载引擎(用缓存,只加载一次,避免每次交互都重建索引)
# ----------------------------------------------------------------------
@st.cache_resource(show_spinner="正在初始化 CrossBridge AI 引擎...")
def load_engine():
    return CrossBridgeRAG("knowledge_base.json")

rag = load_engine()


# ----------------------------------------------------------------------
# 侧边栏
# ----------------------------------------------------------------------
with st.sidebar:
    st.title("🌉 CrossBridge AI")
    st.caption("跨境普惠金融决策助手 · B2B")
    st.divider()

    region_label = st.selectbox("📍 选择地区", list(REGIONS.keys()))
    topic_label = st.selectbox("📂 选择主题", list(TOPICS.keys()))

    st.divider()
    st.markdown("**检索后端**: " +
                ("语义向量" if rag.index.backend == "semantic" else "TF-IDF 关键词"))
    st.markdown(f"**知识库**: {len(rag.docs)} 条资料")
    st.divider()
    st.info("本工具提供初步跨境金融情报,不取代法律或金融专业人士。"
            "最终操作前请向银行客户经理确认。")


# ----------------------------------------------------------------------
# 主区域
# ----------------------------------------------------------------------
st.header("跨境金融,问一句就懂")
st.caption("CrossBridge AI 帮中小企业把跨境政策、汇款、融资讲清楚 —— 每个答案都附权威来源。")

# 示例问题快捷按钮
st.markdown("**试试这些问题:**")
cols = st.columns(2)
for i, q in enumerate(SAMPLE_QUESTIONS):
    if cols[i % 2].button(q, use_container_width=True, key=f"sample_{i}"):
        st.session_state["pending_q"] = q

# 初始化对话历史
if "messages" not in st.session_state:
    st.session_state["messages"] = []

# 显示历史对话
for msg in st.session_state["messages"]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("citations"):
            with st.expander("📚 信息来源(点击展开)"):
                for c in msg["citations"]:
                    st.markdown(
                        f"- **{c['title']}** — {c['source']} "
                        f"｜地区: {c['region']}｜生效: {c['date']}｜相关度: {c['score']}  \n"
                        f"  🔗 {c['url']}"
                    )

# 处理输入(来自快捷按钮或输入框)
user_q = st.chat_input("输入你的跨境金融问题…")
if "pending_q" in st.session_state:
    user_q = st.session_state.pop("pending_q")

if user_q:
    # 显示用户问题
    st.session_state["messages"].append({"role": "user", "content": user_q})
    with st.chat_message("user"):
        st.markdown(user_q)

    # 生成答案
    with st.chat_message("assistant"):
        with st.spinner("正在检索权威资料并生成答案…"):
            result = rag.ask(
                user_q,
                region=REGIONS[region_label],
                topic=TOPICS[topic_label],
                top_k=3,
            )
        st.markdown(result["answer"])
        if result["citations"]:
            with st.expander("📚 信息来源(点击展开)"):
                for c in result["citations"]:
                    st.markdown(
                        f"- **{c['title']}** — {c['source']} "
                        f"｜地区: {c['region']}｜生效: {c['date']}｜相关度: {c['score']}  \n"
                        f"  🔗 {c['url']}"
                    )

    st.session_state["messages"].append({
        "role": "assistant",
        "content": result["answer"],
        "citations": result["citations"],
    })
